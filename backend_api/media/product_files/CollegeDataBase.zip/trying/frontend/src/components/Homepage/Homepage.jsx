import React from 'react';
import './HomePage.css';

const HomePage = () => {
  return (
    <div className="container">
      <h1 className="title">Welcome to Our College Management System</h1>
      <p className="description">
        This application is designed to manage various aspects of a college, including students, courses, instructors, and departments. Our system allows administrators to handle student enrollments, course registrations, and more efficiently.
      </p>
      <section className="section">
        <h2 className="section-title">Project Details</h2>
        <ul className="list">
          <li className="list-item">- Manage students and their courses</li>
          <li className="list-item">- Handle instructor assignments</li>
          <li className="list-item">- Department management</li>
          <li className="list-item">- Schedule exams and view performance</li>
        </ul>
      </section>
      <section className="section">
        <h2 className="section-title">Made By</h2>
        <p className="description">
          Vedant Sarawagi (BT22CSE221)
        </p>
      </section>
      <footer className="footer">
        <p className="footer-text">© 2024 College Management System. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
