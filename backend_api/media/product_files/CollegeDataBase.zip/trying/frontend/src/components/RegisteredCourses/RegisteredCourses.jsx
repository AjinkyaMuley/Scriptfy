import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './RegisteredCourses.css'; // Import the CSS file

function RegisteredCourses() {
  const { student_id } = useParams();
  const [rgc, setRgc] = useState([]);

  useEffect(() => {
    axios.get(`http://localhost:3000/students/registeredCourses/${student_id}`)
      .then(response => {
        console.log(response);
        setRgc(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, [student_id]);

  return (
    <div className="table-container">
      <h1>Courses Opted by {rgc.length > 0 ? rgc[0].student_name : 'Loading...'}</h1>
      <table>
        <thead>
          <tr>
            <th>Course ID</th>
            <th>Course Name</th>
          </tr>
        </thead>
        <tbody>
          {rgc.map((i, index) => (
            <tr key={index}>
              <td>{i.c_id}</td>
              <td>{i.c_name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default RegisteredCourses;
