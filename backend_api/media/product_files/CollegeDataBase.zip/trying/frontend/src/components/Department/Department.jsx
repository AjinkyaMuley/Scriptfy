import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Department.css'; // Import the CSS file

function Department() {
  const [department, setDepartment] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/department')
      .then(response => {
        console.log(response);
        setDepartment(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  return (
    <div className="table-container">
      <h1>Department List</h1>
      <table>
        <thead>
          <tr>
            <th>Department ID</th>
            <th>Department Name</th>
          </tr>
        </thead>
        <tbody>
          {department.map(i => (
            <tr key={i.dp_id}>
              <td>{i.dp_id}</td>
              <td>{i.dp_name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Department;
