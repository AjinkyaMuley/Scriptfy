import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AddStudent.css';

function AddStudent() {
    const [studentName, setStudentName] = useState('');
    const [selectedCourses, setSelectedCourses] = useState([]);
    const [course, setCourse] = useState([]);

    function unCheck() {
        var x = document.getElementsByClassName("checkbox");
        let i;
        for(i=0; i<x.length; i++) {
           x[i].checked = false;
         }   
      }

    useEffect(() => {
        axios.get('http://localhost:3000/courses')
          .then(response => {
            setCourse(response.data);
          })
          .catch(error => {
            console.error('There was an error fetching the data!', error);
          });
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        const data = {
            student_name: studentName,
            c_id: selectedCourses
        };

        axios.post('http://localhost:3000/students/add', data)
            .then(response => {
                setStudentName('');
                setSelectedCourses([]);
                alert(`Student ${studentName} has been added successfully!`);
            })
            .catch(error => {
                console.error('There was an error adding the student:', error);
                alert(`Error ! Please try again`);
            });
        unCheck();
    };

    const handleCourseChange = (c_id) => {
        setSelectedCourses(prevSelected =>
            prevSelected.includes(c_id)
                ? prevSelected.filter(id => id !== c_id)
                : [...prevSelected, c_id]
        );
    };

    return (
        <form className="student-form" onSubmit={handleSubmit}>
            <div className="form-group">
                <label>Student Name:</label>
                <input 
                    type="text" 
                    value={studentName} 
                    onChange={e => setStudentName(e.target.value)} 
                    required 
                />
            </div>

            <div className="form-group">
                <label>Select Courses:</label>
                {course.map(c => {
                    return (
                        <div key={c.c_id} className="checkbox-group">
                            <input className="checkbox" 
                                type="checkbox" 
                                value={c.c_id}
                                onChange={() => handleCourseChange(c.c_id)} 
                            /> 
                            <span>{c.c_name}</span>
                        </div>
                    );
                })}
            </div>
            <button className="submit-button" type="submit">Add Student</button>
        </form>
    );
}

export default AddStudent;
