import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Instructor.css'; // Import the CSS file

function Instructor() {
  const [instructor, setInstructor] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/instructors')
      .then(response => {
        console.log(response);
        setInstructor(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  return (
    <div className="table-container">
      <h1>Instructor List</h1>
      <table>
        <thead>
          <tr>
            <th>Instructor ID</th>
            <th>Instructor Name</th>
            <th>Instructor Department</th>
          </tr>
        </thead>
        <tbody>
          {instructor.map(i => (
            <tr key={i.i_id}>
              <td>{i.i_id}</td>
              <td>{i.isHead ? i.i_name + " (HOD)" : i.i_name}</td>
              <td>{i.dp_id === 1 ? "CSE" : "ECE"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Instructor;
