import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Courses.css'; // Import the CSS file

function Courses() {
  const [course, setCourse] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/courses')
      .then(response => {
        console.log(response);
        setCourse(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  return (
    <div className="table-container">
      <h1>Course List</h1>
      <table>
        <thead>
          <tr>
            <th>Course ID</th>
            <th>Course Name</th>
            <th>Department</th>
            <th>Instructor</th>
          </tr>
        </thead>
        <tbody>
          {course.map(i => (
            <tr key={i.c_id}>
              <td>{i.c_id}</td>
              <td>{i.c_name}</td>
              <td>{i.dp_name}</td>
              <td>{i.i_name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Courses;
