import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Admin = () => {
  const [pincode, setPincode] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const correctPincode = '1234';

  const handlePincodeChange = (e) => {
    setPincode(e.target.value);
  };

  const handlePincodeSubmit = (e) => {
    e.preventDefault();
    if (pincode === correctPincode) {
      setIsVerified(true);
    } else {
      alert('Incorrect pincode. Please try again.');
    }
  };

  return (
    <div style={styles.container}>
      {!isVerified ? (
        <div style={styles.verificationContainer}>
          <h1 style={styles.title}>Admin Dashboard</h1>
          <form onSubmit={handlePincodeSubmit} style={styles.form}>
            <label htmlFor="pincode" style={styles.label}>Enter Passcode:</label>
            <input
              type="password"
              id="pincode"
              value={pincode}
              onChange={handlePincodeChange}
              style={styles.input}
              required
            />
            <button type="submit" style={styles.button}>Verify</button>
          </form>
        </div>
      ) : (
        <div style={styles.linkContainer}>
          <h1 style={styles.title}>Admin Dashboard</h1>
          <Link to='/students/delete' style={styles.link}>Remove Student</Link>
          <Link to='/students/add' style={styles.link}>Add Student</Link>
          <Link to='/students/update' style={styles.link}>Update Student</Link>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
  },
  title: {
    fontSize: '24px',
    marginBottom: '20px',
  },
  linkContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '10px',
  },
  link: {
    textDecoration: 'none',
    color: '#007bff',
    fontSize: '18px',
    fontWeight: 'bold',
    border: '1px solid #007bff',
    padding: '10px 20px',
    borderRadius: '5px',
    backgroundColor: '#f8f9fa',
    transition: 'background-color 0.3s ease',
  },
  linkHover: {
    backgroundColor: '#007bff',
    color: '#fff',
  },
  verificationContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '10px',
  },
  label: {
    fontSize: '18px',
  },
  input: {
    fontSize: '16px',
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    width: '200px',
  },
  button: {
    fontSize: '16px',
    padding: '10px 20px',
    borderRadius: '5px',
    border: 'none',
    backgroundColor: '#007bff',
    color: '#fff',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  },
};

export default Admin;
