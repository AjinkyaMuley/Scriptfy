import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './DeleteStudent.css';

function DeleteStudents() {
    const [students, setStudents] = useState([]);
    const [selectedStudents, setSelectedStudents] = useState([]);
    const [refresh, setRefresh] = useState(false);

    function unCheck() {
        var x = document.getElementsByClassName("checkbox");
        let i;
        for(i=0; i<x.length; i++) {
           x[i].checked = false;
         }   
      }

    useEffect(() => {
        axios.get('http://localhost:3000/students')
            .then(response => {
                setStudents(response.data);
            })
            .catch(error => {
                console.error('Error fetching students:', error);
            });
    }, [refresh]);

    const handleStudentSelection = (student_id) => {
        setSelectedStudents(prevSelected =>
            prevSelected.includes(student_id)
                ? prevSelected.filter(id => id !== student_id)
                : [...prevSelected, student_id]
        );
    };

    const handleDelete = () => {
        const data = {
            student_ids: selectedStudents,
        };

        axios.delete('http://localhost:3000/students/delete', { data })
            .then(response => {
                console.log('Deleted students:', response.data);
                setSelectedStudents([]);
                alert('Students deleted successfully!');
                unCheck();
                setRefresh(prev => !prev);
            })
            .catch(error => {
                console.error('Error deleting students:', error);
                alert('Error! Please try again.');
            });
    };

    return (
        <div className="delete-students-container">
            <h1 className="title">Delete Students</h1>
            <ul className="student-list">
                {students.map(student => (
                    <li key={student.student_id} className="student-item">
                        <label>
                            <input 
                                className="checkbox"
                                type="checkbox" 
                                value={student.student_id}
                                onChange={() => handleStudentSelection(student.student_id)} 
                            />
                            <span className="student-name">{student.student_name}</span>
                        </label>
                    </li>
                ))}
            </ul>
            <button className="delete-button" onClick={handleDelete}>Delete Selected Students</button>
        </div>
    );
}

export default DeleteStudents;
