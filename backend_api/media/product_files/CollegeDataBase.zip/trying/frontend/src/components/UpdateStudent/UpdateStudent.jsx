import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './UpdateStudent.css';

const UpdateStudent = () => {
    const [sid, setSid] = useState('');
    const [person, setPerson] = useState([]);
    const [isfetched, setisfetched] = useState(false);
    const [ChangeName, setChangeName] = useState('');
    const [selectedCourses, setSelectedCourses] = useState([]);
    const [course, setCourse] = useState([]);

    function unCheck() {
        var x = document.getElementsByClassName("checkbox");
        let i;
        for(i=0; i<x.length; i++) {
           x[i].checked = false;
        }   
    }

    useEffect(() => {
        axios.get('http://localhost:3000/courses')
          .then(response => {
            setCourse(response.data);
          })
          .catch(error => {
            console.error('There was an error fetching the data!', error);
          });
    }, []);

    const HandleForm = (e) => {
        e.preventDefault();

        if(!sid){
            console.log('Student id is required');
            return ;
        }
        axios.get(`http://localhost:3000/students/${sid}`)
        .then(response=>{
            console.log(response.data);
            setPerson(response.data);
            setisfetched(true);
        })
        .catch(error=>{
            console.error('There was an error fetching the data!', error);
        });
    }

    useEffect(() => {
        if (person && person.length > 0) {
            setChangeName(person[0].student_name);
        }
    }, [person]);

    const handleCourseChange = (c_id) => {
        setSelectedCourses(prevSelected =>
            prevSelected.includes(c_id)
                ? prevSelected.filter(id => id !== c_id)
                : [...prevSelected, c_id]
        );
    };

    const HandleUpdates = (e) => {
        e.preventDefault();

        const data = {
            student_id: sid,
            student_name: ChangeName,
            courses: selectedCourses
        };

        axios.put('http://localhost:3000/students/update', data)
        .then(response=>{
            alert('Student updated successfully!');
            setSid('');
            setPerson([]);
            setChangeName('');
            setisfetched(false);
            setCourse([]);
            setSelectedCourses([]);
        })
        .catch(error => {
            console.error('There was an error updating the student:', error);
            alert(`Error! Please try again.`);
        });
        unCheck();
    }

    return (
        <div className="container">
            {isfetched ? 
              <div>
                <form onSubmit={HandleUpdates}>
                    <label>Student Name</label>
                    <input type="text" value={ChangeName} onChange={e => setChangeName(e.target.value)}></input>
                    {course.map(c => {
                        return(
                            <div key={c.c_id} className="checkbox-group">
                                <input className="checkbox" 
                                    type="checkbox" 
                                    value={c.c_id}
                                    onChange={() => handleCourseChange(c.c_id)} 
                                /> 
                                <span>{c.c_name}</span>
                            </div>
                        )
                    })}
                    <button type="submit">Update Details</button>
                </form>
              </div>
            : 
              <form onSubmit={HandleForm}>
                <label>Enter Student Id</label>
                <input type="text" value={sid} onChange={e => setSid(e.target.value)} required/>
                <button type="submit">Find Student</button>
              </form>
            }
        </div>
    )
}

export default UpdateStudent;
