import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css'; // Import the CSS file

const Navbar = () => {
    const location = useLocation();
  
    return (
        <nav className="navbar">
            <ul className="navbar-menu">
                <li><Link to="/" className="navbar-item">Home</Link></li>
                <li><Link to="/departments" className="navbar-item">Departments</Link></li>
                <li><Link to="/courses" className="navbar-item">Courses</Link></li>
                <li><Link to="/instructors" className="navbar-item">Instructors</Link></li>
                <li><Link to="/students" className="navbar-item">Students</Link></li>
                {location.pathname !== '/admin' && (
                    <li><Link to="/admin" className="navbar-item special-link">Are you an admin? Click Here</Link></li>
                )}
            </ul>
        </nav>
    );
}

export default Navbar;
