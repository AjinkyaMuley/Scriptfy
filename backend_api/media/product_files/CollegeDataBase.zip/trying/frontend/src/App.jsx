import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar/Navbar';
import Student from './components/Student/Student';
import Instructor from './components/Instructor/Instructor';
import Department from './components/Department/Department';
import Courses from './components/Courses/Courses';
import RegisteredCourses from './components/RegisteredCourses/RegisteredCourses';
import Admin from './components/Admin/Admin';
import AddStudent from './components/AddStudent/AddStudent';
import DeleteStudent from './components/DeleteStudent/DeleteStudent';
import HomePage from './components/Homepage/Homepage';
import UpdateStudent from './components/UpdateStudent/UpdateStudent';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path='/' element={<HomePage />}></Route>
        <Route path='/students' element={<Student />}></Route>
        <Route path='/instructors' element={<Instructor />}></Route>
        <Route path='/departments' element={<Department />}></Route>
        <Route path='/courses' element={<Courses />}></Route>
        <Route path='/admin' element={<Admin />}></Route>
        <Route path='/students/add' element={<AddStudent />}></Route>
        <Route path='/students/delete' element={<DeleteStudent />}></Route>
        <Route path='/students/update' element={<UpdateStudent />}></Route>
        <Route path='/students/registeredCourses/:student_id' element={<RegisteredCourses />}></Route>
      </Routes>
    </Router>
  );
}

export default App;
