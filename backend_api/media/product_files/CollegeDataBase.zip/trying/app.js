const express=require('express');
const db=require('./trying');
const app= express();
const cors = require('cors');
const bodyParser = require('body-parser');

app.use(cors());
app.use(bodyParser.json());

app.get('/students',(req,res)=>{
    db.connect();
    db.connection.query('SELECT * FROM students', (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json(results);
      console.table(results);
    });
    // db.disconnect();
})

app.get('/students/:id',(req,res)=>{
    db.connect();
    const sid=req.params.id;
    const query='SELECT * FROM students where student_id =?';
    db.connection.query(query,[sid],(err,results,fields)=>{
      if(err) throw err;
      else res.status(200).json(results);
      console.log(results);
      //db.disconnect();
    })
})
app.get('/students/registeredCourses/:student_id',(req,res)=>{
    const sid=req.params.student_id;
    const query = `
    SELECT 
      s.student_id, 
      s.student_name, 
      c.c_id, 
      c.c_name
    FROM 
      course_student cs
    JOIN 
      students s ON cs.student_id = s.student_id
    JOIN 
      courses c ON cs.c_id = c.c_id
    WHERE 
      s.student_id = ?;
  `;
    db.connect();
    db.connection.query(query,[sid], (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json(results);
      console.table(results);
    });
    // db.disconnect();
})

app.put('/students/update', (req, res) => {
  const { student_id, student_name, courses } = req.body;

  const updateStudentQuery = 'UPDATE students SET student_name = ? WHERE student_id = ?';
  const deleteCoursesQuery = 'DELETE FROM course_student WHERE student_id = ?';
  const insertCoursesQuery = 'INSERT INTO course_student (student_id, c_id) VALUES ?';

  db.connection.beginTransaction(err => {
      if (err) throw err;

      db.connection.query(updateStudentQuery, [student_name, student_id], (err, result) => {
          if (err) {
              return db.connection.rollback(() => {
                  throw err;
              });
          }

          db.connection.query(deleteCoursesQuery, [student_id], (err, result) => {
              if (err) {
                  return db.connection.rollback(() => {
                      throw err;
                  });
              }

              if (courses.length > 0) {
                  const courseValues = courses.map(c_id => [student_id, c_id]);

                  db.connection.query(insertCoursesQuery, [courseValues], (err, result) => {
                      if (err) {
                          return db.connection.rollback(() => {
                              throw err;
                          });
                      }

                      db.connection.commit(err => {
                          if (err) {
                              return db.connection.rollback(() => {
                                  throw err;
                              });
                          }
                          res.status(200).json({ message: 'Student updated successfully' });
                      });
                  });
              } else {
                  db.connection.commit(err => {
                      if (err) {
                          return db.connection.rollback(() => {
                              throw err;
                          });
                      }
                      res.status(200).json({ message: 'Student updated successfully' });
                  });
              }
          });
      });
  });
});



app.post('/students/add', (req, res) => {
    const{student_name,c_id}=req.body;
    const query = 'INSERT INTO students (student_name) VALUES (?)';

    db.connect();

    // Execute the first query to insert a student
    db.connection.query(query, [student_name], (err, results, fields) => {
        if (err) {
            db.disconnect();
            return res.status(500).json({ message: 'Error inserting student', error: err });
        }

        const student_id = results.insertId;
        const courseStudentQuery = 'INSERT INTO course_student (student_id, c_id) VALUES ?';
        const values = c_id.map(c_id => [student_id, c_id]);

        db.connection.query(courseStudentQuery, [values], (err) => {
            if (err) return db.connection.rollback(() => { throw err; });

            db.connection.commit(err => {
                if (err) return db.connection.rollback(() => { throw err; });
                res.status(200).json({ message: 'Student added successfully', student_id });
          });
        });
    });
});

app.delete('/students/delete', (req, res) => {
  const { student_ids } = req.body;

  if (!student_ids || student_ids.length === 0) {
      return res.status(400).json({ message: 'No student IDs provided' });
  }

  const query = 'DELETE FROM students WHERE student_id IN (?)';

  db.connect();
  db.connection.query(query, [student_ids], (err, results) => {
      if (err) {
          console.error('Error deleting students:', err);
          return res.status(500).json({ message: 'Failed to delete students' });
      }

      res.status(200).json({ message: 'Students deleted successfully', affectedRows: results.affectedRows });
  });
  // db.disconnect();
});


app.get('/instructors',(req,res)=>{
    db.connect();
    db.connection.query('SELECT * FROM instructor', (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json(results);
      console.table(results);
    });
    // db.disconnect();
})
app.get('/courses',(req,res)=>{
    db.connect();
        const query=`SELECT 
        c.c_id, 
        c.c_name, 
        i.i_name, 
        d.dp_name
        FROM 
        courses c
        JOIN 
        instructor i ON c.i_id = i.i_id
        JOIN 
        department d ON c.dp_id = d.dp_id;
        `;
    db.connection.query(query, (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json(results);
      console.table(results);
    });
    // db.disconnect();
})

app.get('/department',(req,res)=>{
    db.connect();
    db.connection.query('SELECT * FROM department', (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json(results);
      console.table(results);
    });
    // db.disconnect();
})

app.get('/join',(req,res)=>{
    db.connect();
    db.connection.query('SELECT * FROM course_student', (err, results, fields) => {
      if (err) throw err;
      else res.status(200).json({message:'success'});
      console.table(results);
    });
    // db.disconnect();
})

app.listen(3000,()=>{
    console.log("Server live on port 3000");
}
)