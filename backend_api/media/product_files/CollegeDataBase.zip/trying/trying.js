const mysql = require('mysql2');

// Create a connection to the local MySQL database
const connection = mysql.createConnection({
  host: '127.0.0.1',       // Localhost (127.0.0.1) for a local MySQL server
  user: 'root',    // Your MySQL username
  password: '8235',// Your MySQL password
  database: 'assign1' // The database you want to connect to
});

// Connect to the database
async function connect(){
  await connection.connect((err) => {
    if (err) {
      console.error('Error connecting to the database:', err.stack);
      return;
    }
    console.log('Connected to the database with ID:', connection.threadId);
  });
}

async function disconnect(){
  connection.end((err) => {
    if (err) {
      console.error('Error ending the connection:', err.stack);
      return;
    }
    console.log('Disconnected from the database.');
  });
}

module.exports={connect,connection,disconnect};


// // Example query: Show tables
// connection.query('SELECT * FROM student_info', (err, results, fields) => {
//   if (err) throw err;
//   console.table(results);
// });

// // Close the connection
// connection.end((err) => {
//   if (err) {
//     console.error('Error ending the connection:', err.stack);
//     return;
//   }
//   console.log('Disconnected from the database.');
// });
